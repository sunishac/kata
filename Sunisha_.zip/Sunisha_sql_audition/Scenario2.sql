/*
	Scenario 2:
	New orders came into the staging area for (2008-05-01). Merge these orders with the existing orders for the same date.
*/
USE Kata;
GO
