/*
	Scenario 1:
	There was an error in the order entry system that caused duplicate order lines to get entered into the database. Remove the duplicate order lines.
	BONUS: Modify the database so that this error cannot happen again.
*/
USE Kata;
GO
