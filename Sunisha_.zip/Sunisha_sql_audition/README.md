# SQLCodeKata
