#!/usr/bin/python


def main():
    return it_runs()


def it_runs():
    return True


if __name__ == "__main__":
    main()
